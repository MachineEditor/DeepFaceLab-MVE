from models import ModelBase
from models import TrainingDataType
import numpy as np
import cv2

from nnlib import tf_dssim
from nnlib import conv
from nnlib import upscale
from facelib import FaceType

class Model(ModelBase):

    encoderH5 = 'encoder.h5'
    decoder_srcH5 = 'decoder_src.h5'
    decoder_src_maskH5 = 'decoder_src_mask.h5'
    decoder_dstH5 = 'decoder_dst.h5'
    

    #override
    def onInitialize(self, batch_size=-1, **in_options):
        tf = self.tf
        keras = self.keras
        K = keras.backend
        
        if self.gpu_total_vram_gb < 5:
            raise Exception ('Sorry, this model works only on 5GB+ GPU')
            
        self.batch_size = batch_size
        if self.batch_size == 0:     
            if self.gpu_total_vram_gb <= 5:
                self.batch_size = 4
            elif self.gpu_total_vram_gb <= 6:
                self.batch_size = 8
            elif self.gpu_total_vram_gb < 12: 
                self.batch_size = 16
            else:    
                self.batch_size = 48 #best for all models
                
        self.encoder, self.decoder_src, self.decoder_src_mask, self.decoder_dst = self.BuildAE( 128 )   
        img_shape      = K.int_shape(self.encoder.inputs[0])[1:]
        img_mask_shape = K.int_shape(self.decoder_src_mask.outputs[0])[1:]
        
        if not self.is_first_run():
            self.encoder.load_weights     (self.get_strpath_storage_for_file(self.encoderH5))
            self.decoder_src.load_weights (self.get_strpath_storage_for_file(self.decoder_srcH5))
            self.decoder_src_mask.load_weights (self.get_strpath_storage_for_file(self.decoder_src_maskH5))
            self.decoder_dst.load_weights (self.get_strpath_storage_for_file(self.decoder_dstH5))
            

        if self.is_training_mode:
            self.encoder, self.decoder_src, self.decoder_src_mask, self.decoder_dst = self.to_multi_gpu_model_if_possible ( [self.encoder, self.decoder_src, self.decoder_src_mask, self.decoder_dst] )
        
        input_src_target      = keras.layers.Input(img_shape)
        input_src_target_mask = keras.layers.Input(img_mask_shape)
        input_dst_target      = keras.layers.Input(img_shape)
        input_dst_target_mask = keras.layers.Input(img_mask_shape)

        src_code = self.encoder(input_src_target)
        dst_code = self.encoder(input_dst_target)
        
        rec_src = self.decoder_src(src_code)
        rec_src_mask = self.decoder_src_mask(src_code)
        rec_dst = self.decoder_dst(dst_code)        
        
        src_loss = tf_dssim(tf, (input_src_target/2+0.5)*(input_src_target_mask/2+0.5), (rec_src/2+0.5)*(input_src_target_mask/2+0.5))
        src_mask_loss = K.mean(K.abs(rec_src_mask-input_src_target_mask))
        dst_loss = tf_dssim(tf, (input_dst_target/2+0.5)*(input_dst_target_mask/2+0.5), (rec_dst/2+0.5)*(input_dst_target_mask/2+0.5))        
        total_loss = src_loss + dst_loss + src_mask_loss                  

        self.ed_train = K.function ([input_src_target, input_src_target_mask, input_dst_target, input_dst_target_mask],[K.mean(src_loss), K.mean(dst_loss)],
                                       self.keras.optimizers.Adam(lr=5e-5, beta_1=0.5, beta_2=0.999).get_updates(total_loss, self.encoder.trainable_weights + self.decoder_src.trainable_weights + self.decoder_dst.trainable_weights + self.decoder_src_mask.trainable_weights)
                                     )
                                     
        self.src_view = K.function ([input_src_target], [rec_src])
        self.src_view_src_mask = K.function ([input_src_target], [rec_src, rec_src_mask])
        self.dst_view = K.function ([input_dst_target], [rec_dst])
        
        
        if self.is_training_mode:
            from models import TrainingDataGenerator
            f = TrainingDataGenerator.SampleTypeFlags 
            self.set_training_data_generators ([            
                    TrainingDataGenerator(TrainingDataType.FACE, self.training_data_src_path, debug=self.is_debug(), normalize_tanh=True, batch_size=self.batch_size, output_sample_types=[ [f.TRANSFORMED | f.FULL_FACE | f.MODE_BGR, 128], [f.TRANSFORMED | f.FULL_FACE | f.MODE_M | f.MASK_FULL, 128] ] ),
                    TrainingDataGenerator(TrainingDataType.FACE, self.training_data_dst_path, debug=self.is_debug(), normalize_tanh=True, batch_size=self.batch_size, output_sample_types=[ [f.TRANSFORMED | f.FULL_FACE | f.MODE_BGR, 128], [f.TRANSFORMED | f.FULL_FACE | f.MODE_M | f.MASK_FULL, 128] ] )
                ])
    #override
    def onSave(self):        
        self.save_weights_safe( [[self.encoder, self.get_strpath_storage_for_file(self.encoderH5)],
                                 [self.decoder_src, self.get_strpath_storage_for_file(self.decoder_srcH5)],
                                 [self.decoder_src_mask, self.get_strpath_storage_for_file(self.decoder_src_maskH5)],
                                 [self.decoder_dst, self.get_strpath_storage_for_file(self.decoder_dstH5)] ] )
        
    #override
    def onTrainOneEpoch(self, sample):
        target_src, target_src_mask = sample[0]
        target_dst, target_dst_mask = sample[1]    
  
        loss_src, loss_dst = self.ed_train ([target_src, target_src_mask, target_dst, target_dst_mask])   
        
        return ( ('loss_src', loss_src), ('loss_dst', loss_dst) )

    #override
    def onGetPreview(self, sample):
        test_A   = sample[0][0][0:4] #first 4 samples
        test_A_m = sample[0][1][0:4] #first 4 samples
        test_B   = sample[1][0][0:4]
        test_B_m = sample[1][1][0:4]
        
        AA,      = self.src_view ([test_A])
        AB, mAB, = self.src_view_src_mask ([test_B])
        BB,      = self.dst_view ([test_B])
 
        test_A, test_B, AA, AB, mAB, BB,   = [ np.clip(x / 2 + 0.5, 0.0, 1.0) for x in [test_A, test_B, AA, AB, mAB, BB] ]
 
        mAB = np.repeat (mAB, (3,), -1)
 
        st = []
        for i in range(0, len(test_A)):
            st.append ( np.concatenate ( (
                test_A[i],
                AA[i],
                test_B[i],                
                BB[i],
                AB[i],
                AB[i]*mAB[i],
                test_B[i]*(1-mAB[i])+AB[i]*mAB[i],
                ), axis=1) )
        return [ ('src, dst, src->dst', np.concatenate ( st, axis=0 ) ) ]

    def predictor_func (self, face):
        
        face_128_bgr = face[...,0:3]
        face_128_mask = np.expand_dims(face[...,3],-1)
        
        x, mx = self.autoencoder_src.predict ( [ np.expand_dims(face_128_bgr,0), np.expand_dims(face_128_mask,0) ] )
        x, mx = x[0], mx[0]
        
        return np.concatenate ( (x,mx), -1 )
        
    #override
    def get_converter(self, **in_options):
        from models import ConverterMasked
        
        if 'erode_mask_modifier' not in in_options.keys():
            in_options['erode_mask_modifier'] = 0
        in_options['erode_mask_modifier'] += 30
            
        if 'blur_mask_modifier' not in in_options.keys():
            in_options['blur_mask_modifier'] = 0
            
        return ConverterMasked(self.predictor_func, predictor_input_size=128, output_size=128, face_type=FaceType.FULL, clip_border_mask_per=0.046875, **in_options)
   
    def BuildAE(self, dim):
        keras, K = self.keras, self.keras.backend
        
        encoder_input = keras.layers.Input ( (dim, dim, 3) )
        x = encoder_input
        x = keras.layers.convolutional.Conv2D(90, kernel_size=5, strides=1, padding='same')(x)
        x = keras.layers.convolutional.Conv2D(90, kernel_size=5, strides=1, padding='same')(x)
        x = keras.layers.MaxPooling2D(pool_size=(3, 3), strides=2, padding='same')(x)
        
        x = keras.layers.convolutional.Conv2D(180, kernel_size=3, strides=1, padding='same')(x)
        x = keras.layers.convolutional.Conv2D(180, kernel_size=3, strides=1, padding='same')(x)
        x = keras.layers.MaxPooling2D(pool_size=(3, 3), strides=2, padding='same')(x)
        
        x = keras.layers.convolutional.Conv2D(360, kernel_size=3, strides=1, padding='same')(x)
        x = keras.layers.convolutional.Conv2D(360, kernel_size=3, strides=1, padding='same')(x)
        x = keras.layers.MaxPooling2D(pool_size=(3, 3), strides=2, padding='same')(x)
        
        x = keras.layers.Dense (1024)(x)
        x = keras.layers.advanced_activations.LeakyReLU(0.1)(x)
        x = keras.layers.Dropout(0.5)(x)
        
        x = keras.layers.Dense (1024)(x)
        x = keras.layers.advanced_activations.LeakyReLU(0.1)(x)
        x = keras.layers.Dropout(0.5)(x)
        x = keras.layers.Flatten()(x)
        x = keras.layers.Dense (128)(x)
        
        encoder = keras.models.Model (encoder_input, x)

        def decoder():
            decoder_input = keras.layers.Input ( K.int_shape(encoder.outputs[0])[1:] )
            x = decoder_input
            
            x = keras.layers.Dense (16*16*1024)(x)
            x = keras.layers.Reshape ( (16,16,1024) )(x)
            x = upscale(keras, x, 360)
            x = upscale(keras, x, 180)
            x = upscale(keras, x, 90)
            x = keras.layers.convolutional.Conv2D(3, kernel_size=5, padding='same', activation='tanh')(x)
            return keras.models.Model(decoder_input, x)
        
        decoder_input = keras.layers.Input ( K.int_shape(encoder.outputs[0])[1:] )
        x = decoder_input
        x = keras.layers.Dense (16*16*512)(x)
        x = keras.layers.Reshape ( (16,16,512) )(x)
        x = upscale(keras, x, 360)
        x = upscale(keras, x, 180)
        x = upscale(keras, x, 90)
        x = keras.layers.convolutional.Conv2D(1, kernel_size=5, padding='same', activation='tanh')(x)
        decoder_mask = keras.models.Model(decoder_input, x)

        return encoder, decoder(), decoder_mask, decoder()
   
        