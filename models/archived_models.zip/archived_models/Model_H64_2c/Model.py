from models import ModelBase
from models import TrainingDataType
import numpy as np

from nnlib import tf_dssim
from nnlib import conv
from nnlib import upscale
from facelib import FaceType

class Model(ModelBase):

    encoderH5 = 'encoder.h5'
    decoder_srcH5 = 'decoder_src.h5'
    decoder_dstH5 = 'decoder_dst.h5'

    #override
    def onInitialize(self, **in_options):
        tf = self.tf
        keras = self.keras
        K = keras.backend
        
        self.set_vram_batch_requirements( {1.5:2,2:2,3:4,4:8,5:16,6:32,7:32,8:32,9:48} )
        
        bgr_shape, mask_shape, self.encoder, self.decoder_src, self.decoder_dst = self.Build(self.created_vram_gb)
        
        if not self.is_first_run():
            self.encoder.load_weights     (self.get_strpath_storage_for_file(self.encoderH5))
            self.decoder_src.load_weights (self.get_strpath_storage_for_file(self.decoder_srcH5))
            self.decoder_dst.load_weights (self.get_strpath_storage_for_file(self.decoder_dstH5))
            
        if self.is_training_mode:
            self.encoder, self.decoder_src, self.decoder_dst = self.to_multi_gpu_model_if_possible ( [self.encoder, self.decoder_src, self.decoder_dst] )
        
        bgr_src_input = self.keras.layers.Input(shape=bgr_shape)
        bgr_src_target = self.keras.layers.Input(shape=bgr_shape)
        mask_src_input = self.keras.layers.Input(shape=mask_shape)
        
        bgr_dst_input = self.keras.layers.Input(shape=bgr_shape)
        bgr_dst_target = self.keras.layers.Input(shape=bgr_shape)
        mask_dst_input = self.keras.layers.Input(shape=mask_shape)
        
        src_code = self.encoder(bgr_src_input)
        bgr_src_rec, bgr_src_rec_mask = self.decoder_src(src_code)
        
        dst_code = self.encoder(bgr_dst_input)
        bgr_dst_rec, bgr_dst_rec_mask = self.decoder_dst(dst_code)
        
        loss_src = K.mean (tf_dssim(tf, bgr_src_target*mask_src_input, bgr_src_rec*mask_src_input)) + \
                   K.mean (K.abs(bgr_src_rec_mask-mask_src_input))
                    
        loss_dst = K.mean (tf_dssim(tf, bgr_dst_input*mask_dst_input , bgr_dst_rec*mask_dst_input)) + \
                   K.mean (K.abs(bgr_dst_rec_mask-mask_dst_input))
                   
        total_loss = loss_src + loss_dst    
      
        self.ae_train = K.function ([bgr_src_input, bgr_src_target, mask_src_input, bgr_dst_input, bgr_dst_target, mask_dst_input],[loss_src, loss_dst],
                                       self.keras.optimizers.Adam(lr=5e-5, beta_1=0.5, beta_2=0.999).get_updates(total_loss, self.encoder.trainable_weights + self.decoder_src.trainable_weights + self.decoder_dst.trainable_weights)
                                     )
        
        self.src_view = K.function ([bgr_src_input], [bgr_src_rec, bgr_src_rec_mask])
        self.dst_view = K.function ([bgr_dst_input], [bgr_dst_rec, bgr_dst_rec_mask])

        if self.is_training_mode:
            from models import TrainingDataGenerator
            f = TrainingDataGenerator.SampleTypeFlags 
            self.set_training_data_generators ([    
                    TrainingDataGenerator(TrainingDataType.FACE, self.training_data_src_path, debug=self.is_debug(), batch_size=self.batch_size, output_sample_types=[ [f.WARPED_TRANSFORMED | f.HALF_FACE | f.MODE_BGR, 64], [f.TRANSFORMED | f.HALF_FACE | f.MODE_BGR, 64], [f.TRANSFORMED | f.HALF_FACE | f.MODE_M | f.MASK_FULL, 64] ], random_flip=True ),
                    TrainingDataGenerator(TrainingDataType.FACE, self.training_data_dst_path, debug=self.is_debug(), batch_size=self.batch_size, output_sample_types=[ [f.WARPED_TRANSFORMED | f.HALF_FACE | f.MODE_BGR, 64], [f.TRANSFORMED | f.HALF_FACE | f.MODE_BGR, 64], [f.TRANSFORMED | f.HALF_FACE | f.MODE_M | f.MASK_FULL, 64] ], random_flip=True )
                ])
                
    #override
    def onSave(self):        
        self.save_weights_safe( [[self.encoder, self.get_strpath_storage_for_file(self.encoderH5)],
                                [self.decoder_src, self.get_strpath_storage_for_file(self.decoder_srcH5)],
                                [self.decoder_dst, self.get_strpath_storage_for_file(self.decoder_dstH5)]] )
        
    #override
    def onTrainOneEpoch(self, sample):
        warped_src, target_src, target_src_full_mask = sample[0]
        warped_dst, target_dst, target_dst_full_mask = sample[1]    
        
        loss_src, loss_dst = self.ae_train( [warped_src, target_src, target_src_full_mask, warped_dst, target_dst, target_dst_full_mask] )

        return ( ('loss_src', loss_src), ('loss_dst', loss_dst) )
        
    #override
    def onGetPreview(self, sample):
        test_A   = sample[0][1][0:4] #first 4 samples
        test_A_m = sample[0][2][0:4]
        test_B   = sample[1][1][0:4]
        test_B_m = sample[1][2][0:4]
        
        AA, mAA = self.src_view([test_A, test_A_m])                                       
        AB, mAB = self.src_view([test_B, test_B_m])
        BB, mBB = self.dst_view([test_B, test_B_m])
        
        mAA = np.repeat ( mAA, (3,), -1)
        mAB = np.repeat ( mAB, (3,), -1)
        mBB = np.repeat ( mBB, (3,), -1)
        
        st = []
        for i in range(0, len(test_A)):
            st.append ( np.concatenate ( (
                test_A[i,:,:,0:3],
                AA[i],
                #mAA[i],
                test_B[i,:,:,0:3], 
                BB[i], 
                #mBB[i],                
                AB[i],
                #mAB[i]
                ), axis=1) )
            
        return [ ('H64', np.concatenate ( st, axis=0 ) ) ]

    def predictor_func (self, face):
        
        face_64_bgr = face[...,0:3]
        face_64_mask = np.expand_dims(face[...,3],-1)
        
        x, mx = self.autoencoder_src.predict ( [ np.expand_dims(face_64_bgr,0), np.expand_dims(face_64_mask,0) ] )
        x, mx = x[0], mx[0]     
        
        return np.concatenate ( (x,mx), -1 )

    #override
    def get_converter(self, **in_options):
        from models import ConverterMasked
        
        if 'erode_mask_modifier' not in in_options.keys():
            in_options['erode_mask_modifier'] = 0
        in_options['erode_mask_modifier'] += 100
            
        if 'blur_mask_modifier' not in in_options.keys():
            in_options['blur_mask_modifier'] = 0
        in_options['blur_mask_modifier'] += 100
        
        return ConverterMasked(self.predictor_func, predictor_input_size=64, output_size=64, face_type=FaceType.HALF, **in_options)
    
    def Build(self, created_vram_gb):
        keras = self.keras
        K = self.keras.backend
        
        bgr_shape = (64, 64, 3)
        mask_shape = (64, 64, 1)
        
        bgr_input = keras.layers.Input(shape=bgr_shape)
        mask_input = keras.layers.Input(shape=mask_shape)
        
        def Encoder(input_layer):
            x = input_layer
            if created_vram_gb >= 4:
                x = conv(keras, x, 128)
                x = conv(keras, x, 256)
                x = conv(keras, x, 512)
                x = conv(keras, x, 1024)
                x = keras.layers.Dense(1024)(keras.layers.Flatten()(x))
                x = keras.layers.Dense(4 * 4 * 1024)(x)
                x = keras.layers.Reshape((4, 4, 1024))(x)
                x = upscale(keras, x, 512)
            else:
                x = conv(keras, x, 128 )
                x = conv(keras, x, 256 )
                x = conv(keras, x, 512 )
                x = conv(keras, x, 768 )
                x = keras.layers.Dense(512)(keras.layers.Flatten()(x))
                x = keras.layers.Dense(4 * 4 * 512)(x)
                x = keras.layers.Reshape((4, 4, 512))(x)
                x = upscale(keras, x, 256)
                
            return keras.models.Model(input_layer, x)
        
        
        def Decoder(encoder):
            input_ = keras.layers.Input ( K.int_shape(encoder.outputs[0])[1:] )

            x = input_
            x = upscale(keras, x, 256)
            x = upscale(keras, x, 128)
            x = upscale(keras, x, 64)
            
            y = input_  #mask decoder
            y = upscale(keras, y, 256)
            y = upscale(keras, y, 128)
            y = upscale(keras, y, 64)
            
            x = self.keras.layers.convolutional.Conv2D(3, kernel_size=5, padding='same', activation='sigmoid')(x)
            y = self.keras.layers.convolutional.Conv2D(1, kernel_size=5, padding='same', activation='sigmoid')(y)            
            
            return self.keras.models.Model(input_, [x,y])
        
        encoder = Encoder(bgr_input)
            
        return bgr_shape, mask_shape, encoder, Decoder(encoder), Decoder(encoder)